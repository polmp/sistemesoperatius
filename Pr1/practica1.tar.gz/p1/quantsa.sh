#!/bin/sh
ls $1 | grep a | wc -l