#!/bin/sh
sudo find $HOME -atime +90 -type f


